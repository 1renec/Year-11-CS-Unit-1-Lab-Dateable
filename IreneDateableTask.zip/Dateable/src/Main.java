import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int myAge;
        System.out.println("Enter your age:");
        myAge = scan.nextInt();
        int dateAge = myAge/2+7;
        System.out.println(myAge + " year olds should date somebody who is at least "+ dateAge + " years old");
    }
}